import flet as ft
import random

class PassGen(ft.UserControl):
    def build(self):
        self.input = ft.TextField(hint_text = "Length of the Password ?", expand = True)
        self.password_text = ft.Text(size=20, weight=ft.FontWeight.BOLD, color=ft.colors.BLUE)
        view = ft.Column(
                controls = [
                    ft.Text(value = "PassGen", style  = ft.TextThemeStyle.HEADLINE_MEDIUM),
                    ft.Row(
                        controls = [
                            self.input,
                            ft.FloatingActionButton(icon = ft.icons.VPN_KEY_ROUNDED, on_click = self.gen_key)
                            ]
                        ),
                    self.password_text,                    ]
                )
        return view

    def gen_key(self, e):
        if self.input.value != '':
            lower = "abcdefghijklmnopqrstuvwxyz"
            upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            numbers = "1234567890"
            symbols = """~`!@#$%^&*()_+-={}[]:"|<>?;',./"""
            a = lower + upper + numbers + symbols
            password = "".join(random.sample(a, (int(self.input.value))))
            self.password_text.value = password
            self.input.value = ''
            self.update()
        else:
            pass


    def remove_task(self, task):
        self.tasks.controls.remove(task)
        self.update()


def main(page: ft.Page):
    pas = PassGen()
    page.add(pas)
    page.update


ft.app(target = main)
